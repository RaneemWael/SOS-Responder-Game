package model.people;

public enum CitizenState {
	DECEASED, RESCUED, IN_TROUBLE,SAFE
}
